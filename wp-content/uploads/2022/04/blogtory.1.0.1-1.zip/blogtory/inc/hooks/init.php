<?php
require get_template_directory() . '/inc/hooks/template-hooks.php';
require get_template_directory() . '/inc/hooks/tgm.php';

require get_template_directory() . '/inc/hooks/template-functions/header.php';
require get_template_directory() . '/inc/hooks/template-functions/homepage.php';
require get_template_directory() . '/inc/hooks/template-functions/footer.php';